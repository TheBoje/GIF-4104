# GIF4104 - TP3 - MPI - Équipe 1

- Compilation

```bash
make
```

- Lancement

```bash
mpirun -np [nombre_processus] main [taille_matrice]
# exemple
mpirun -np 4 main 1024
```